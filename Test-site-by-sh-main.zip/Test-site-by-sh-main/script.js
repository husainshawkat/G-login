// এখানে JavaScript ফাংশন যোগ করতে পারো, যেমন প্লে-বাটন ইফেক্ট বা অটো-লিরিক স্ক্রল
console.log("Music Lyrics Website Loaded!");
